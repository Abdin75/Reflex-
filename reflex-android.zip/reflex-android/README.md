# مدرّب ردّ الفعل (Android / Java)
بناء APK: ارفع المشروع إلى GitHub، ثم Actions ← Build APK ← Run workflow، وحمّل ReflexTrainer-APK من Artifacts.
ملاحظة: مجلد `.github` مخفي؛ إن لم يُرفع، أنشئ الملف يدوياً: Add file ← Create new file باسم `.github/workflows/build.yml`.
مفتاح المرور الافتراضي: Reflex-2026. لتغييره: `printf '%s' 'مفتاحك' | sha256sum` ثم ضع الناتج في HASHES داخل MainActivity.java.
الدفع: ضع رابطاً في PAY_URL، أو أضف Google Play Billing عند النشر على المتجر.
