package com.reflex.trainer;

import android.app.Activity;
import android.content.*;
import android.graphics.*;
import android.net.Uri;
import android.os.*;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.security.MessageDigest;
import java.util.*;

public class MainActivity extends Activity {
    // بصمات SHA-256 لمفاتيح المرور المسموحة (المفتاح الافتراضي: Reflex-2026)
    static final String[] HASHES = {"07eeeaff99484a7a688dd5133a2d2354af47163b4b05c40d64708cb2e2faef41"};
    static final String PAY_URL = ""; // ضع رابط الدفع الحقيقي هنا
    static final String[] TABS = {"ردّ الفعل", "التصويب", "الخطة", "السجل", "التعديل"};
    static final int GRAY = 0xFF667085, DARK = 0xFF14181F, BG = 0xFFE5E7EB, BLUE = 0xFF2563EB;
    static final String DEF = "اضبط الأزرار: الحركة يسار والهجوم يمين\n10 اختبارات ردّ فعل وسجّل المتوسط\n"
        + "اختبار تصويب مرتين بدقة لا بسرعة\nتوقّع مكان الظهور قبل الهدف\nإحماء دقيقتين ثم ردّ الفعل\n"
        + "جلسة مهارة واحدة 20 دقيقة\nراحة وراجع السجل\nكرّر الاختبارين وقارن\nخطة قتال من ثلاث خطوات\n"
        + "تصويب 3 مرات بحساسية ثابتة\nردّ الفعل وأنت مرتاح\nجلسة قتال قصيرة وراجعها\nراحة ونوم كافٍ\nاختبار نهائي وقارن بالبداية";

    SharedPreferences sp;
    LinearLayout body;
    Handler hd = new Handler(Looper.getMainLooper());
    float d;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        d = getResources().getDisplayMetrics().density;
        sp = getSharedPreferences("rt", MODE_PRIVATE);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFFF6F7F9);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setPadding(dp(12), dp(28), dp(12), dp(8));
        HorizontalScrollView hs = new HorizontalScrollView(this);
        LinearLayout bar = new LinearLayout(this);
        for (int i = 0; i < TABS.length; i++) { final int k = i; bar.addView(btn(TABS[i], v -> show(k))); }
        hs.addView(bar);
        root.addView(hs);
        body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        root.addView(body, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);
        show(0);
    }

    int dp(int v) { return (int) (v * d); }
    TextView tv(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(0, dp(6), 0, dp(6)); return t;
    }
    Button btn(String s, View.OnClickListener l) { Button b = new Button(this); b.setText(s); b.setOnClickListener(l); return b; }

    void show(int k) {
        body.removeAllViews();
        switch (k) { case 0: reaction(); break; case 1: aim(); break; case 2: plan(); break; case 3: logv(); break; default: edit(); }
    }

    // ---------- التخزين ----------
    void addLog(String t, int v) {
        try {
            JSONArray a = new JSONArray(sp.getString("log", "[]")), e = new JSONArray();
            e.put(t); e.put(v); a.put(e);
            while (a.length() > 300) a.remove(0);
            sp.edit().putString("log", a.toString()).apply();
        } catch (Exception x) { }
    }
    List<Integer> vals(String t) {
        List<Integer> r = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(sp.getString("log", "[]"));
            for (int i = 0; i < a.length(); i++) if (a.getJSONArray(i).getString(0).equals(t)) r.add(a.getJSONArray(i).getInt(1));
        } catch (Exception x) { }
        return r;
    }
    File[] imgFiles() { File[] f = new File(getFilesDir(), "img").listFiles(); return f == null ? new File[0] : f; }
    String sha(String s) {
        try {
            StringBuilder b = new StringBuilder();
            for (byte x : MessageDigest.getInstance("SHA-256").digest(s.getBytes("UTF-8"))) b.append(String.format("%02x", x));
            return b.toString();
        } catch (Exception e) { return ""; }
    }

    // ---------- اختبار ردّ الفعل ----------
    void reaction() {
        body.addView(tv("اضغط للبدء. حين يصبح المربع أخضر اضغط فوراً. الضغط المبكر يلغي المحاولة.", 14, GRAY));
        final TextView box = new TextView(this);
        box.setGravity(Gravity.CENTER); box.setTextSize(20); box.setText("ابدأ");
        box.setBackgroundColor(BG); box.setTextColor(DARK);
        body.addView(box, new LinearLayout.LayoutParams(-1, dp(240)));
        final int[] st = {0};
        final long[] t0 = {0};
        final Runnable go = () -> { st[0] = 2; box.setBackgroundColor(0xFF16A34A); box.setText("اضغط الآن!"); t0[0] = System.nanoTime(); };
        box.setOnTouchListener((v, e) -> {
            if (e.getAction() != MotionEvent.ACTION_DOWN) return true;
            if (st[0] == 0) {
                st[0] = 1; box.setBackgroundColor(0xFFDC2626); box.setText("انتظر الأخضر…");
                hd.postDelayed(go, 1000 + (long) (Math.random() * 3000));
            } else if (st[0] == 1) {
                hd.removeCallbacks(go); st[0] = 0; box.setBackgroundColor(BG); box.setText("مبكر جداً! اضغط للمحاولة");
            } else {
                int ms = (int) ((System.nanoTime() - t0[0]) / 1000000);
                st[0] = 0; box.setBackgroundColor(BG); box.setText(ms + " مللي ثانية\nاضغط للإعادة");
                addLog("r", ms);
            }
            return true;
        });
    }

    // ---------- اختبار التصويب ----------
    class AimView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float x, y, r = dp(30);
        int n, miss; long t0, tot; boolean run;
        String[] msg = {"15 هدفاً: اضغط كل دائرة بأسرع ما يمكن", "اضغط للبدء"};
        AimView(Context c) { super(c); setBackgroundColor(BG); }
        void next() {
            x = r + (float) Math.random() * (getWidth() - 2 * r);
            y = r + (float) Math.random() * (getHeight() - 2 * r);
            t0 = System.nanoTime();
        }
        @Override protected void onDraw(Canvas c) {
            if (run) { p.setColor(BLUE); c.drawCircle(x, y, r, p); return; }
            p.setColor(DARK); p.setTextSize(dp(16)); p.setTextAlign(Paint.Align.CENTER);
            for (int i = 0; i < msg.length; i++) c.drawText(msg[i], getWidth() / 2f, getHeight() / 2f + i * dp(28), p);
        }
        @Override public boolean onTouchEvent(MotionEvent e) {
            if (e.getAction() != MotionEvent.ACTION_DOWN) return true;
            if (!run) { n = 0; miss = 0; tot = 0; run = true; next(); invalidate(); return true; }
            float dx = e.getX() - x, dy = e.getY() - y;
            if (dx * dx + dy * dy <= r * r * 1.4f) {
                tot += System.nanoTime() - t0; n++;
                if (n >= 15) {
                    run = false; int avg = (int) (tot / 15 / 1000000);
                    msg = new String[]{"المتوسط " + avg + " مللي ثانية | الأخطاء " + miss, "اضغط للإعادة"};
                    addLog("a", avg);
                } else next();
            } else miss++;
            invalidate(); return true;
        }
    }
    void aim() { body.addView(new AimView(this), new LinearLayout.LayoutParams(-1, dp(420))); }

    // ---------- الخطة ----------
    void plan() {
        ScrollView sv = new ScrollView(this);
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); sv.addView(l);
        for (File f : imgFiles()) {
            ImageView iv = new ImageView(this); iv.setAdjustViewBounds(true);
            iv.setImageBitmap(BitmapFactory.decodeFile(f.getPath())); l.addView(iv);
        }
        String[] p = sp.getString("plan", DEF).split("\n");
        for (int i = 0; i < p.length; i++) {
            final String key = "" + i;
            CheckBox c = new CheckBox(this);
            c.setText("يوم " + (i + 1) + ": " + p[i]);
            c.setChecked(sp.getStringSet("done", new HashSet<>()).contains(key));
            c.setOnCheckedChangeListener((b, on) -> {
                Set<String> s = new HashSet<>(sp.getStringSet("done", new HashSet<>()));
                if (on) s.add(key); else s.remove(key);
                sp.edit().putStringSet("done", s).apply();
            });
            l.addView(c);
        }
        body.addView(sv);
    }

    // ---------- السجل ----------
    class Graph extends View {
        List<Integer> a; Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Graph(Context c, List<Integer> a) { super(c); this.a = a; p.setColor(BLUE); p.setStrokeWidth(dp(2)); }
        @Override protected void onDraw(Canvas c) {
            if (a.size() < 2) return;
            int mx = Collections.max(a), mn = Collections.min(a);
            float r = Math.max(1, mx - mn), w = getWidth(), h = getHeight() - dp(12), s = w / (a.size() - 1);
            for (int i = 1; i < a.size(); i++)
                c.drawLine((i - 1) * s, dp(6) + h - (a.get(i - 1) - mn) / r * h, i * s, dp(6) + h - (a.get(i) - mn) / r * h, p);
        }
    }
    void logv() {
        for (String t : new String[]{"r", "a"}) {
            List<Integer> a = vals(t);
            body.addView(tv(t.equals("r") ? "ردّ الفعل (مللي ثانية)" : "التصويب (مللي ثانية لكل هدف)", 16, DARK));
            if (a.isEmpty()) { body.addView(tv("لا توجد نتائج بعد.", 14, GRAY)); continue; }
            int n = Math.min(10, a.size()), sum = 0;
            for (int i = a.size() - n; i < a.size(); i++) sum += a.get(i);
            body.addView(tv("الأفضل: " + Collections.min(a) + " | متوسط آخر " + n + ": " + sum / n + " | المحاولات: " + a.size(), 14, GRAY));
            body.addView(new Graph(this, a.subList(Math.max(0, a.size() - 30), a.size())), new LinearLayout.LayoutParams(-1, dp(90)));
        }
        body.addView(tv("الأقل أفضل. هبوط الخط يعني تحسناً.", 13, GRAY));
        body.addView(btn("مسح السجل", v -> { sp.edit().remove("log").apply(); show(3); }));
    }

    // ---------- التعديل (مقفل) ----------
    void edit() {
        if (!sp.getBoolean("u", false)) {
            body.addView(tv("التعديل مقفل. أدخل مفتاح المرور، أو ادفع 0.99$ للحصول على مفتاح.", 15, DARK));
            final EditText pk = new EditText(this);
            pk.setHint("مفتاح المرور");
            pk.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
            body.addView(pk);
            final TextView ms = tv("", 14, 0xFFDC2626);
            body.addView(btn("فتح", v -> {
                if (Arrays.asList(HASHES).contains(sha(pk.getText().toString().trim()))) {
                    sp.edit().putBoolean("u", true).apply(); show(4);
                } else ms.setText("المفتاح غير صحيح.");
            }));
            body.addView(btn("ادفع 0.99$", v -> {
                if (PAY_URL.isEmpty()) ms.setText("رابط الدفع لم يُضبط بعد.");
                else startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(PAY_URL)));
            }));
            body.addView(ms);
            return;
        }
        ScrollView sv = new ScrollView(this);
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); sv.addView(l);
        l.addView(tv("تعديل الخطة (سطر لكل يوم)", 16, DARK));
        final EditText pt = new EditText(this);
        pt.setText(sp.getString("plan", DEF)); pt.setMinLines(8); pt.setGravity(Gravity.TOP | Gravity.START);
        pt.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        l.addView(pt);
        l.addView(btn("حفظ الخطة", v -> {
            String s = pt.getText().toString().trim();
            if (!s.isEmpty()) { sp.edit().putString("plan", s).apply(); Toast.makeText(this, "تم الحفظ", Toast.LENGTH_SHORT).show(); }
        }));
        l.addView(btn("استيراد خطة من ملف نصي", v -> pick("text/*", 2)));
        l.addView(btn("الخطة الأصلية", v -> { sp.edit().remove("plan").apply(); show(4); }));
        l.addView(btn("إضافة صور (حتى 12)", v -> pick("image/*", 1)));
        l.addView(btn("حذف كل الصور", v -> { for (File f : imgFiles()) f.delete(); show(4); }));
        l.addView(btn("قفل التعديل", v -> { sp.edit().putBoolean("u", false).apply(); show(4); }));
        body.addView(sv);
    }
    void pick(String type, int rq) {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType(type); i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, rq == 1);
        startActivityForResult(i, rq);
    }
    @Override protected void onActivityResult(int rq, int rs, Intent it) {
        super.onActivityResult(rq, rs, it);
        if (rs != RESULT_OK || it == null) return;
        List<Uri> us = new ArrayList<>();
        if (it.getClipData() != null) for (int i = 0; i < it.getClipData().getItemCount(); i++) us.add(it.getClipData().getItemAt(i).getUri());
        else if (it.getData() != null) us.add(it.getData());
        try {
            if (rq == 2) {
                BufferedReader r = new BufferedReader(new InputStreamReader(getContentResolver().openInputStream(us.get(0)), "UTF-8"));
                StringBuilder sb = new StringBuilder(); String ln;
                while ((ln = r.readLine()) != null) if (!ln.trim().isEmpty()) sb.append(ln.trim()).append("\n");
                r.close();
                if (sb.length() > 0) sp.edit().putString("plan", sb.toString().trim()).apply();
            } else {
                File dir = new File(getFilesDir(), "img"); dir.mkdirs();
                for (Uri u : us) {
                    if (dir.list().length >= 12) break;
                    BitmapFactory.Options o = new BitmapFactory.Options(); o.inJustDecodeBounds = true;
                    InputStream s = getContentResolver().openInputStream(u); BitmapFactory.decodeStream(s, null, o); s.close();
                    o.inJustDecodeBounds = false; o.inSampleSize = Math.max(1, Math.max(o.outWidth, o.outHeight) / 800);
                    s = getContentResolver().openInputStream(u); Bitmap bm = BitmapFactory.decodeStream(s, null, o); s.close();
                    if (bm != null) {
                        FileOutputStream fo = new FileOutputStream(new File(dir, System.nanoTime() + ".jpg"));
                        bm.compress(Bitmap.CompressFormat.JPEG, 80, fo); fo.close();
                    }
                }
            }
        } catch (Exception e) { Toast.makeText(this, "تعذّر قراءة الملف", Toast.LENGTH_SHORT).show(); }
        show(4);
    }
}
